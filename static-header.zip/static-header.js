
// Template Header - Testing with tailwind






const basic_header = document.createElement('div');
basic_header.className = "header"
basic_header.style.width = "100%";
basic_header.style.height = "20%";
basic_header.style.backgroundColor = "red"
basic_header.style.position = "absolute"
basic_header.style.top = "0"
basic_header.style.left = "0"
basic_header.style.zIndex = "900"

